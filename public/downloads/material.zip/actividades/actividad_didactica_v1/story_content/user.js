function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6O0mJt3rdOS":
        Script1();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
window.Script1 = function()
{
  window.close();
}

};
